#this program uses the pet class

import pet

def main():
    #local variables
    pet_name = ""
    pet_type = ""
    pet_age = 0

    #get pet data

    pet_name = input("What is your pet's name? ")
    pet_type = input("What type of pet do you have? ")
    pet_age = int(input("How old is your pet? "))

    # Create an instance of the Pet class

    mypet = pet.Pet(pet_name, pet_type, pet_age)

    #Display pey info

    print("Here is your pet's name:", mypet.get_name())
    print("Type of pet you have:", mypet.get_animal_type())
    print("Your pet's age:", mypet.get_age())



main()
    
