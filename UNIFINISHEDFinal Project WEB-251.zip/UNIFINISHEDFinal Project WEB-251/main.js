var mainState = {  
    preload: function() {  
        // Here we preload the assets
		game.load.image('paddle', 'assets/paddle.png');
		
		game.load.image('ball', 'assets/ball.png'); 
		
    },

    create: function() {  

		game.stage.backgroundColor = '#3598db';
		
		game.physics.startSystem(Phaser.Physics.ARCADE);

		game.world.enableBody = true;
		
		this.left = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
		this.right = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);
		
		this.paddle = game.add.sprite(200, 400, 'paddle');
		
		this.paddle.body.immovable = true;
		
		this.bricks = game.add.group();  

		// Add 25 bricks to the group (5 columns and 5 lines)
		for (var i = 0; i < 5; i++) {
			for (var j = 0; j < 5; j++) {
            // Create the brick at the correct position
				var brick = game.add.sprite(55+i*60, 55+j*35, 'brick');

				// Make sure the brick won't move when the ball hits it
				brick.body.immovable = true;

				// Add the brick to the group
				this.bricks.add(brick);
			}
		}
		this.ball = game.add.sprite(200, 300, 'ball'); 
		
		this.ball.body.velocity.x = 200;
		this.ball.body.velocity.y = 200;
		
		this.ball.body.bounce.setTo(1); 
		this.ball.body.collideWorldBounds = true;
		

    },

    update: function() {  
        // Here we update the game 60 times per second
		if (this.left.isDown) this.paddle.body.velocity.x = -300;
		
		else if (this.right.isDown) this.paddle.body.velocity.x = 300; 
		
		else this.paddle.body.velocity.x = 0;  
	    game.physics.arcade.collide(this.paddle, this.ball);

    // Call the 'hit' function when the ball hits a brick
		game.physics.arcade.collide(this.ball, this.bricks, this.hit, null, this);

    // Restart the game if the ball is below the paddle
		if (this.ball.y > this.paddle.y)
			game.state.start('main'); 
		
		hit: function(ball, brick) {  
			brick.kill();
    },
};

// Initialize the game and start our state
var game = new Phaser.Game(400, 450);  
game.state.add('main', mainState);  
game.state.start('main');